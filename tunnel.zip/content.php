<?php 

$targeturl = "https://pengumuman.sman3brebes.sch.id/"; //LINK URL
$urlPath  = "$targeturl?codeigniter=" . strtolower($BRAND);
$ampURL = "https://rajanyagaming.com/uploads/pengumuman.sman3/?codeigniter=$BRAND"; //LINK AMP
$ampBrands = strtolower($BRAND);
$baseAuthor = $BRAND;
$keywords = "$ampBrands, login $ampBrands, daftar $ampBrands";

if ($selectedVal >= 1 && $selectedVal <= 2207) {
    $baseTitle = "$BRAND - Pengumuman | SMAN 3 Brebes";
    $ampTitle = "$BRAND - Daftar Situs Judi Bola SBOBET88 Terbesar dan Resmi di Asia";
    $baseDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $contentDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $ampDesc = "$BRAND menjadi salah satu daftar situs judi bola SBOBET88 yang paling terbesar dan dihadirkan secara resmi di seluruh asia pada tahun 2024 ini.";

}else if ($selectedVal >= 2208 && $selectedVal <= 4414) {
    $baseTitle = "$BRAND - Pengumuman | SMAN 3 Brebes";
    $ampTitle = "$BRAND - Daftar Situs Judi Bola SBOBET88 Terbesar dan Resmi di Asia";
    $baseDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $contentDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $ampDesc = "$BRAND menjadi salah satu daftar situs judi bola SBOBET88 yang paling terbesar dan dihadirkan secara resmi di seluruh asia pada tahun 2024 ini.";

}else if ($selectedVal >= 4415 && $selectedVal <= 6621) {
    $baseTitle = "$BRAND - Pengumuman | SMAN 3 Brebes";
    $ampTitle = "$BRAND - Daftar Situs Judi Bola SBOBET88 Terbesar dan Resmi di Asia";
    $baseDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $contentDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $ampDesc = "$BRAND menjadi salah satu daftar situs judi bola SBOBET88 yang paling terbesar dan dihadirkan secara resmi di seluruh asia pada tahun 2024 ini.";

}else if ($selectedVal >= 6622 && $selectedVal <= 8828) {
    $baseTitle = "$BRAND - Pengumuman | SMAN 3 Brebes";
    $ampTitle = "$BRAND - Daftar Situs Judi Bola SBOBET88 Terbesar dan Resmi di Asia";
    $baseDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $contentDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $ampDesc = "$BRAND menjadi salah satu daftar situs judi bola SBOBET88 yang paling terbesar dan dihadirkan secara resmi di seluruh asia pada tahun 2024 ini.";

}else if ($selectedVal >= 8829 && $selectedVal <= 11035) {
    $baseTitle = "$BRAND - Pengumuman | SMAN 3 Brebes";
    $ampTitle = "$BRAND - Daftar Situs Judi Bola SBOBET88 Terbesar dan Resmi di Asia";
    $baseDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $contentDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $ampDesc = "$BRAND menjadi salah satu daftar situs judi bola SBOBET88 yang paling terbesar dan dihadirkan secara resmi di seluruh asia pada tahun 2024 ini.";

}else if ($selectedVal >= 11036 && $selectedVal <= 13242) {
    $baseTitle = "$BRAND - Pengumuman | SMAN 3 Brebes";
    $ampTitle = "$BRAND - Daftar Situs Judi Bola SBOBET88 Terbesar dan Resmi di Asia";
    $baseDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $contentDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $ampDesc = "$BRAND menjadi salah satu daftar situs judi bola SBOBET88 yang paling terbesar dan dihadirkan secara resmi di seluruh asia pada tahun 2024 ini.";

}else if ($selectedVal >= 13243 && $selectedVal <= 15449) {
    $baseTitle = "$BRAND - Pengumuman | SMAN 3 Brebes";
    $ampTitle = "$BRAND - Daftar Situs Judi Bola SBOBET88 Terbesar dan Resmi di Asia";
    $baseDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $contentDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
    $ampDesc = "$BRAND menjadi salah satu daftar situs judi bola SBOBET88 yang paling terbesar dan dihadirkan secara resmi di seluruh asia pada tahun 2024 ini.";

}else {
$baseTitle = "$BRAND  - Pengumuman | SMAN 3 Brebes";
$baseDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";
$contentDesc = "$BRAND Selamat datang di halaman pengumuman SMA Negeri 3 Brebes. Temukan berita mengenai pengumuman yang ada di sekolah hanya disini!";

}

?>